---
name: Earth Online
colors:
  surface: '#161308'
  surface-dim: '#161308'
  surface-bright: '#3d392c'
  surface-container-lowest: '#110e05'
  surface-container-low: '#1f1b10'
  surface-container: '#231f14'
  surface-container-high: '#2e2a1e'
  surface-container-highest: '#393528'
  on-surface: '#eae2cf'
  on-surface-variant: '#d0c6ab'
  inverse-surface: '#eae2cf'
  inverse-on-surface: '#343024'
  outline: '#999077'
  outline-variant: '#4d4732'
  surface-tint: '#e9c400'
  primary: '#fff6df'
  on-primary: '#3a3000'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#705d00'
  secondary: '#66dd8b'
  on-secondary: '#003919'
  secondary-container: '#25a55a'
  on-secondary-container: '#003115'
  tertiary: '#defcff'
  on-tertiary: '#00363a'
  tertiary-container: '#00f1ff'
  on-tertiary-container: '#006a70'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#83fba5'
  secondary-fixed-dim: '#66dd8b'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005227'
  tertiary-fixed: '#79f5ff'
  tertiary-fixed-dim: '#00dbe8'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#161308'
  on-background: '#eae2cf'
  surface-variant: '#393528'
  primary-gold-light: '#DAA520'
  gold-dark: '#B8860B'
  gold-dark-light: '#8B6914'
  accent-orange: '#FF8C00'
  accent-orange-light: '#FF7F50'
  emerald-green-light: '#3CB371'
  bg-dark: '#1A1A2E'
  surface-dark: '#16213E'
  bg-light: '#E8EDF2'
  locked-dark: '#555555'
  locked-light: '#CCCCCC'
  rare-blue: '#4169E1'
  epic-purple: '#800080'
typography:
  headline-lg:
    fontFamily: Press Start 2P
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: Press Start 2P
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 24px
  headline-md:
    fontFamily: Roboto
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-md:
    fontFamily: Roboto
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-md-italic:
    fontFamily: Roboto
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-sm:
    fontFamily: Roboto
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  screen-padding: 16px
  card-padding: 12px
  element-gap: 8px
---

# 地球 Online Design System (Dual Theme)
本設計系統定義「地球 Online」App 的視覺基礎，支援 **深色 RPG 主題** 與 **淺色現代主題**。所有畫面與元件必須同時適配兩種主題，並可即時切換。
## 色彩系統
### 深色主題 (Dark RPG)
| 名稱 | 色碼 | 用途 |
|------|------|------|
| Primary Gold | #FFD700 | 按鈕、成就高亮、寵物屬性條、主要互動 |
| Gold Dark | #B8860B | 邊框、次要按鈕、文字陰影 |
| Emerald Green | #50C878 | 進度條、成功狀態、寵物體力值 |
| Accent Orange | #FF8C00 | CTA 按鈕、新通知提示 |
| Background | #1A1A2E | 主背景，帶有極細微的暗色石頭紋理 |
| Surface | #16213E | 卡片、對話框背景 |
| On Surface | #FFFFFF | 主要文字 |
| Locked | #555555 | 未解鎖成就、禁用狀態 |
| Legendary Glow | #FFD700 (30% 透明度) | 傳說成就邊框外發光 |
### 淺色主題 (Light Modern)
| 名稱 | 色碼 | 用途 |
|------|------|------|
| Primary Gold | #DAA520 | 按鈕、成就高亮、主要互動（稍微沉穩，避免刺眼） |
| Gold Dark | #8B6914 | 邊框、次要元素 |
| Emerald Green | #3CB371 | 進度條、成功狀態 |
| Accent Orange | #FF7F50 | CTA 按鈕 |
| Background | #E8EDF2 | 主背景，淺藍灰，無紋理 |
| Surface | #FFFFFF | 卡片、對話框背景 |
| On Surface | #1A1A1A | 主要文字 |
| Locked | #CCCCCC | 未解鎖成就、禁用狀態 |
| Shadow | #000000 (10% 透明度) | 卡片陰影 |
## 字體排版
- 標題/成就名稱：**Block-style 像素字體** (Press Start 2P 或類似，僅用於深色主題；淺色主題可用 Bold Roboto 替代以維持可讀性)
- 內文：Roboto Regular, 14sp
- 輔助文字：Roboto Regular, 12sp
- 寵物對話氣泡：Roboto Italic, 14sp，略帶圓角背景
## 間距與圓角
- 螢幕內邊距：16dp
- 卡片內邊距：12dp
- 元件間距：8dp
- 卡片圓角：8dp（深色主題帶內縮陰影，淺色主題帶外陰影）
- 按鈕圓角：8dp（遊戲風為 4dp 斜角，現代風為 24dp 全圓角）
## 陰影與立體感
- 深色主題卡片：`inner shadow` 模擬像素風邊框，無外陰影。
- 淺色主題卡片：標準 Material 3 陰影 (elevation 2dp)。
## 成就稀有度邊框
- **普通 (Common)**：無特殊邊框
- **稀有 (Rare)**：#4169E1 邊框，1dp
- **史詩 (Epic)**：#800080 邊框，1.5dp
- **傳說 (Legendary)**：#FFD700 邊框，2dp，並帶有外部發光動畫 (0% → 30% 透明度循環)
## 圖標與插圖
- 標籤圖示使用 Material Icons (填滿)
- 成就圖示可為自訂向量圖或 emoji
- 寵物使用原生系統 emoji（🐉🦊🐱🐶🦄🐲🐰🐼🦋🐙🐢🦅）
## 動畫參數
- 按鈕按下：`scale(0.95)`，持續 100ms，彈回
- 成就彈窗滑入：`slideInVertically` + `spring(dampingRatio=0.6)`，500ms
- 螢火蟲粒子：20~30 個小光點，隨機軌跡，持續 3.5 秒
- 進度條動畫：`animateFloatAsState`，800ms
- 寵物彈跳：`animateFloatAsState` 搭配 `RepeatMode.Reverse`，閒置時輕微上下，點擊時大跳
- 主題切換：整個畫面 `Crossfade` 300ms
